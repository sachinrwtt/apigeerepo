var access_token=context.getVariable("request.queryparam.access_token");
var authHeader=context.getVariable("request.header.Authorization");
var AuthorizationVal;
var isNullAccessToken;
if((access_token!=="") && (access_token !==null)){
AuthorizationVal="Bearer "+access_token;
}
if((authHeader!=="" )&& (authHeader !== null)){
AuthorizationVal=authHeader;
}
context.setVariable("request.header.Authorization",AuthorizationVal);
context.setVariable("access_token",access_token);
context.setVariable("authHeader",authHeader);