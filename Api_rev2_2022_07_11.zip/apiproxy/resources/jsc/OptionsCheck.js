 method = context.getVariable("request.verb"); 
if (method == "OPTIONS")
{
    StatusCode=200;
    ReasonPhrase='OK';
    context.setVariable("StatusCode",200); 
    context.setVariable("ReasonPhrase",'OK'); 
    print("StatusCode "+StatusCode);
    print("ReasonPhrase "+ReasonPhrase);
}
